// config.js
module.exports = {
  allowedRoles: [
    '1007930481716760666',
    '1046786167644880946',
    'ROLE_ID_3',
    'ROLE_ID_4',
  ],
};
